import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  private base = environment.apiUrl;

  /** Headers for requests WITH a JSON body (POST, PUT, PATCH) */
  private get headers(): HttpHeaders {
    const token = localStorage.getItem('token');
    let h = token
      ? new HttpHeaders({ Authorization: `Bearer ${token}` })
      : new HttpHeaders();
    h = h.set('Content-Type', 'application/json');
    return h;
  }

  /** Headers for requests WITHOUT a body (GET, DELETE) — no Content-Type */
  private get authHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return token
      ? new HttpHeaders({ Authorization: `Bearer ${token}` })
      : new HttpHeaders();
  }

  get<T>(path: string) {
    return this.http.get<T>(`${this.base}${path}`, { headers: this.authHeaders });
  }

  post<T>(path: string, body: unknown) {
    return this.http.post<T>(`${this.base}${path}`, body, { headers: this.headers });
  }

  put<T>(path: string, body: unknown) {
    return this.http.put<T>(`${this.base}${path}`, body, { headers: this.headers });
  }

  patch<T>(path: string, body: unknown) {
    return this.http.patch<T>(`${this.base}${path}`, body, { headers: this.headers });
  }

  delete<T>(path: string) {
    return this.http.delete<T>(`${this.base}${path}`, {
      headers: this.authHeaders,
      responseType: 'text' as 'json',
    });
  }

  getBlob(path: string) {
    return this.http.get(`${this.base}${path}`, {
      headers: this.authHeaders,
      responseType: 'blob',
    });
  }
}

